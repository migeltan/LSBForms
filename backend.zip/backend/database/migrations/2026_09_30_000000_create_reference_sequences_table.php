<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('reference_sequences', function (Blueprint $t) {
            $t->id();
            $t->string('prefix', 4);
            $t->unsignedSmallInteger('year');
            $t->unsignedInteger('last_number')->default(0);
            $t->unique(['prefix', 'year']);
        });
    }
    public function down(): void { Schema::dropIfExists('reference_sequences'); }
};