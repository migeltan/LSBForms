<!DOCTYPE html>
<html>
<body style="font-family:Arial,sans-serif;color:#1f2937;max-width:560px;margin:auto;padding:24px">
  <h2 style="color:#1e3a5f;margin:0 0 16px">Legislative Security Bureau</h2>
  <p>Hello <?php echo e($applicantName); ?>,</p>

  <?php if($event === 'submitted'): ?>
    <p>We received your <?php echo e($formType); ?> application. Keep your reference number, you will need it to check your application status.</p>
  <?php elseif($event === 'Approved'): ?>
    <p>Your <?php echo e($formType); ?> application has been <strong>approved</strong>.</p>
  <?php elseif($event === 'Rejected'): ?>
    <p>Your <?php echo e($formType); ?> application was <strong>not approved</strong>.</p>
  <?php else: ?>
    <p>Your <?php echo e($formType); ?> application needs <strong>corrections or a retake</strong> before we can continue. Please see the notes below.</p>
  <?php endif; ?>

  <p style="background:#f3f4f6;border-radius:8px;padding:12px 16px;font-size:18px;letter-spacing:1px">
    Reference No.: <strong><?php echo e($referenceNumber); ?></strong>
  </p>

  <?php if($remarks && $event !== 'submitted'): ?>
    <p><strong>Reviewer remarks:</strong><br><?php echo e($remarks); ?></p>
  <?php endif; ?>

  <p style="color:#6b7280;font-size:12px">This is an automated message. Please do not reply.</p>
</body>
</html><?php /**PATH C:\Program Tools\GITHUB PROG\04_PROJECTS_V2\LSBForms\backend\resources\views/emails/application-status.blade.php ENDPATH**/ ?>