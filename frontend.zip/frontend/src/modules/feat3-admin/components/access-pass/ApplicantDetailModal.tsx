import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { DetailSkeleton } from "../../../../components/ui/Skeleton";
import type {
  ApplicantDetail,
  ApplicationStatus,
  AccessPassUpdatePayload,
  PersonalInformationDraft,
  FamilyBackgroundDraftRow,
  EducationalBackgroundDraftRow,
  DocumentRow,
} from "../../../../hooks/types";
import { TOKEN_KEY } from "../../../../providers/AuthProvider";
import { BASE } from "../../../../hooks/apiConfig";
import { IdPreviewPanel } from "./modal/IdPreviewPanel";
import { PersonalInformationModal } from "./modal/PersonalInformationModal";
import { EducationalBackgroundModal } from "./modal/EducationalBackgroundModal";
import { FamilyBackgroundModal } from "./modal/FamilyBackgroundModal";
import { DocumentsModal } from "./modal/DocumentsModal";
import { SaveCancelModal } from "../../../../components/modals/SaveCancelModal";
import { DeleteModal } from "../../../../components/modals/DeleteModal";
import { CloseButton } from "../../../../components/buttons/CloseButton";

type TabKey = "personal" | "education" | "family" | "documents";

type SaveCancelState = "saving" | "success" | "cancelled" | "confirm-cancel";

const TABS: { key: TabKey; label: string }[] = [
  { key: "personal", label: "Personal Information" },
  { key: "education", label: "Educational Background" },
  { key: "family", label: "Family Background" },
  { key: "documents", label: "Documents" },
];

// Idle tabs are translucent gray; the active tab is highlighted per-key below.
const TAB_IDLE_STYLE =
  "bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200";
const TAB_ACTIVE_STYLE = "bg-[#6aa9f5] text-[#0f2744] border border-[#4f95ee]";

function draftFromDetail(detail: ApplicantDetail): {
  personal: PersonalInformationDraft;
  family: FamilyBackgroundDraftRow[];
  education: EducationalBackgroundDraftRow[];
} {
  const p = detail.personal_information;
  return {
    personal: {
      first_name: p.first_name,
      middle_name: p.middle_name,
      last_name: p.last_name,
      suffix: p.suffix,
      date_of_birth: p.date_of_birth,
      place_of_birth: p.place_of_birth,
      sex: p.sex,
      civil_status: p.civil_status,
      address: p.address,
      contact_number: p.contact_number,
      email: p.email,
      applicant_type: p.applicant_type,
      remarks: p.remarks,
      declaration_name: p.declaration_name,
      declaration_date: p.declaration_date,
    },
    family: detail.family_background.map((f) => ({ ...f })),
    education: detail.educational_background.map((e) => ({ ...e })),
  };
}

export function ApplicantDetailModal({
  applicantId,
  onClose,
  onDeleted,
  onChanged,
}: {
  applicantId: number | null;
  onClose: () => void;
  onDeleted?: () => void;
  onChanged?: () => void;
}) {
  const [detail, setDetail] = useState<ApplicantDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<TabKey>("personal");
  const [reviewing, setReviewing] = useState<boolean>(false);
  const [reviewError, setReviewError] = useState<string | null>(null);

  // Edit mode state — draft copies of the editable fields. Documents
  // are never part of this; they're view/download-only.
  const [editing, setEditing] = useState<boolean>(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [draftPersonal, setDraftPersonal] =
    useState<PersonalInformationDraft | null>(null);
  const [draftFamily, setDraftFamily] = useState(
    [] as FamilyBackgroundDraftRow[],
  );
  const [draftEducation, setDraftEducation] = useState(
    [] as EducationalBackgroundDraftRow[],
  );

  // Delete confirmation flow.
  const [deleteModalOpen, setDeleteModalOpen] = useState<boolean>(false);
  const [deleting, setDeleting] = useState<boolean>(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Controls the SaveCancelModal:
  // "saving" — shown immediately on Save click, while the request is in flight
  // "success" — save completed
  // "confirm-cancel" — "are you sure?" step before discarding edits
  // "cancelled" — the discard actually happened
  // null — hidden
  const [saveCancelModal, setSaveCancelModal] = useState(
    null as SaveCancelState | null,
  );

  useEffect(() => {
    if (applicantId === null) return;

    let cancelled = false;
    setTab("personal");
    setDetail(null);
    setError(null);
    setReviewError(null);
    setEditing(false);
    setSaveError(null);
    setDeleteModalOpen(false);
    setDeleteError(null);
    setLoading(true);

    async function load() {
      try {
        const token = sessionStorage.getItem(TOKEN_KEY);
        const res = await fetch(
          `${BASE}/api/admin/access-pass/${applicantId}`,
          {
            headers: token ? { Authorization: `Bearer ${token}` } : {},
          },
        );
        if (!res.ok) throw new Error("Request failed");
        const data: ApplicantDetail = await res.json();
        if (!cancelled) setDetail(data);
      } catch {
        if (!cancelled) setError("Could not load applicant details.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [applicantId]);

  // Lock background scroll while the modal is open.
  useEffect(() => {
    if (applicantId === null) return;

    const htmlEl = document.documentElement;
    const bodyEl = document.body;

    const prevHtmlOverflow = htmlEl.style.overflow;
    const prevBodyOverflow = bodyEl.style.overflow;
    const prevBodyPosition = bodyEl.style.position;
    const prevBodyTop = bodyEl.style.top;
    const prevBodyWidth = bodyEl.style.width;

    const scrollY = window.scrollY;

    htmlEl.style.overflow = "hidden";
    bodyEl.style.overflow = "hidden";
    bodyEl.style.position = "fixed";
    bodyEl.style.top = `-${scrollY}px`;
    bodyEl.style.width = "100%";

    return () => {
      htmlEl.style.overflow = prevHtmlOverflow;
      bodyEl.style.overflow = prevBodyOverflow;
      bodyEl.style.position = prevBodyPosition;
      bodyEl.style.top = prevBodyTop;
      bodyEl.style.width = prevBodyWidth;
      window.scrollTo(0, scrollY);
    };
  }, [applicantId]);

  if (applicantId === null) return null;

  async function handleReview(status: ApplicationStatus) {
    if (!detail) return;
    setReviewing(true);
    setReviewError(null);
    try {
      const token = sessionStorage.getItem(TOKEN_KEY);
      const res = await fetch(
        `${BASE}/api/admin/access-pass/${detail.profile.application_id}/review`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ status }),
        },
      );
      if (!res.ok) throw new Error("Request failed");
      setDetail({
        ...detail,
        personal_information: { ...detail.personal_information, status },
      });
      onChanged?.();
    } catch {
      setReviewError("Could not update the application status.");
    } finally {
      setReviewing(false);
    }
  }

  function startEditing() {
    if (!detail) return;
    const drafts = draftFromDetail(detail);
    setDraftPersonal(drafts.personal);
    setDraftFamily(drafts.family);
    setDraftEducation(drafts.education);
    setSaveError(null);
    setEditing(true);
  }

  // Called after the user confirms "Yes" on the confirm-cancel step.
  function confirmCancelEditing() {
    setEditing(false);
    setSaveError(null);
    setDraftPersonal(null);
    setDraftFamily([]);
    setDraftEducation([]);
    setSaveCancelModal("cancelled");
  }

  async function handleSave() {
    if (!detail || !draftPersonal) return;
    // Show the loading modal immediately — no spinner on the button itself.
    setSaveCancelModal("saving");
    setSaveError(null);
    try {
      const token = sessionStorage.getItem(TOKEN_KEY);
      const payload: AccessPassUpdatePayload = {
        personal_information: draftPersonal,
        family_background: draftFamily,
        educational_background: draftEducation,
      };
      const res = await fetch(
        `${BASE}/api/admin/access-pass/${detail.profile.applicant_id}/update`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify(payload),
        },
      );
      if (!res.ok) throw new Error("Request failed");
      const updated: ApplicantDetail = await res.json();
      setDetail(updated);
      setEditing(false);
      setDraftPersonal(null);
      setDraftFamily([]);
      setDraftEducation([]);
      setSaveCancelModal("success");
      onChanged?.();
    } catch {
      setSaveError("Could not save changes. Please try again.");
      setSaveCancelModal(null);
    }
  }

  async function handleDelete() {
    if (!detail) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      const token = sessionStorage.getItem(TOKEN_KEY);
      const res = await fetch(
        `${BASE}/api/admin/access-pass/${detail.profile.applicant_id}`,
        {
          method: "DELETE",
          headers: token ? { Authorization: `Bearer ${token}` } : {},
        },
      );
      if (!res.ok) throw new Error("Request failed");
      setDeleteModalOpen(false);
      onDeleted?.();
      onClose();
    } catch {
      setDeleteError("Could not delete this application. Please try again.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <>
      {createPortal(
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 p-3 sm:p-6">
          <div
            className="relative w-full max-w-[1400px] h-full sm:h-[900px] max-h-[95vh] rounded-[28px] p-[1.5px] shadow-[0_25px_70px_-20px_rgba(15,39,68,0.5)]"
            style={{
              background:
                "linear-gradient(135deg, rgba(30,58,95,0.8) 0%, rgba(15,39,68,0.2) 45%, rgba(30,58,95,0.8) 100%)",
            }}
          >
            <div className="relative h-full w-full overflow-hidden rounded-[26.5px] bg-white ring-1 ring-black/5 flex flex-col">
              {/* Header bar */}
              <div className="shrink-0 flex items-center justify-between gap-4 px-8 py-6 text-white bg-[#15304f] sm:px-16 sm:py-8">
                <h2
                  className="truncate text-3xl font-bold tracking-tight"
                  style={{
                    color: "#ffffff",
                    fontFamily: "var(--smart-font-sans)",
                  }}
                >
                  {editing
                    ? "Editing Application Details"
                    : "Application Details"}
                </h2>
                <CloseButton
                  onClick={
                    editing
                      ? () => setSaveCancelModal("confirm-cancel")
                      : onClose
                  }
                  ariaLabel={editing ? "Cancel editing" : "Close"}
                  className="sm:h-12! sm:w-12!"
                />
              </div>

              {/* Body — fixed height, never scrolls as a whole */}
              <div className="flex-1 min-h-0 flex flex-col bg-[#f7f7f5]">
                {loading && <DetailSkeleton />}

                {!loading && error && (
                  <div className="py-16 text-center text-[var(--smart-red,#c0392b)] text-sm font-medium">
                    {error}
                  </div>
                )}
                {!loading && !error && detail && (
                  <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
                    {/* LEFT: preview + actions */}
                    <aside className="flex shrink-0 flex-col overflow-y-auto border-b border-gray-300 px-8 py-8 lg:w-[37%] lg:border-b-0 lg:border-r xl:px-[72px]">
                      <IdPreviewPanel
                        detail={detail}
                        onApprove={() => handleReview("Approved")}
                        onDecline={() => handleReview("Rejected")}
                        reviewing={reviewing}
                        reviewError={reviewError}
                      />
                    </aside>

                    {/* RIGHT: tabs, record, footer */}
                    <section className="flex-1 min-w-0 min-h-0 flex flex-col px-8 py-8 xl:px-14">
                      <div className="shrink-0 flex flex-wrap gap-3 pb-6 border-b border-gray-300">
                        {TABS.map((t) => (
                          <button
                            key={t.key}
                            onClick={() => setTab(t.key)}
                            className={`rounded-2xl px-6 py-2.5 text-sm font-semibold transition-colors ${
                              tab === t.key ? TAB_ACTIVE_STYLE : TAB_IDLE_STYLE
                            }`}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>

                      <div className="flex-1 min-h-0 overflow-y-auto pt-6 pr-2">
                        {tab === "personal" && (
                          <PersonalInformationModal
                            detail={detail}
                            editing={editing}
                            draft={draftPersonal}
                            onChange={(field, value) =>
                              setDraftPersonal((prev) =>
                                prev ? { ...prev, [field]: value } : prev,
                              )
                            }
                          />
                        )}
                        {tab === "education" && (
                          <EducationalBackgroundModal
                            rows={detail.educational_background}
                            editing={editing}
                            draftRows={draftEducation}
                            onChange={(index, field, value) =>
                              setDraftEducation((prev) =>
                                prev.map((row, i) =>
                                  i === index
                                    ? { ...row, [field]: value }
                                    : row,
                                ),
                              )
                            }
                            onAdd={() =>
                              setDraftEducation((prev) => [
                                ...prev,
                                {
                                  school: "",
                                  degree: null,
                                  year_graduated: null,
                                  other_information: null,
                                },
                              ])
                            }
                            onRemove={(index) =>
                              setDraftEducation((prev) =>
                                prev.filter((_, i) => i !== index),
                              )
                            }
                          />
                        )}
                        {tab === "family" && (
                          <FamilyBackgroundModal
                            rows={detail.family_background}
                            editing={editing}
                            draftRows={draftFamily}
                            onChange={(index, field, value) =>
                              setDraftFamily((prev) =>
                                prev.map((row, i) =>
                                  i === index
                                    ? { ...row, [field]: value }
                                    : row,
                                ),
                              )
                            }
                            onAdd={() =>
                              setDraftFamily((prev) => [
                                ...prev,
                                {
                                  relationship: "",
                                  name: "",
                                  occupation: null,
                                  other_information: null,
                                },
                              ])
                            }
                            onRemove={(index) =>
                              setDraftFamily((prev) =>
                                prev.filter((_, i) => i !== index),
                              )
                            }
                          />
                        )}
                        {tab === "documents" && (
                          <DocumentsModal
                            documents={detail.documents}
                            editing={editing}
                            onDocumentUpdated={(updated: DocumentRow) =>
                              setDetail((prev) =>
                                prev
                                  ? {
                                      ...prev,
                                      documents: prev.documents.map((d) =>
                                        d.id === updated.id ? updated : d,
                                      ),
                                    }
                                  : prev,
                              )
                            }
                          />
                        )}
                      </div>

                      {saveError && (
                        <p className="shrink-0 mt-3 text-xs text-[var(--smart-red,#c0392b)]">
                          {saveError}
                        </p>
                      )}

                      {/* Footer actions — fixed, does not scroll */}
                      <div className="shrink-0 flex justify-end gap-3 pt-5 mt-3 border-t border-gray-300">
                        {editing ? (
                          <>
                            <button
                              onClick={() =>
                                setSaveCancelModal("confirm-cancel")
                              }
                              className="rounded-lg bg-white hover:bg-gray-50 text-gray-700 text-sm font-semibold px-6 py-3 ring-1 ring-inset ring-gray-300 transition-colors"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={handleSave}
                              className="rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-6 py-3 shadow-sm transition-colors"
                            >
                              Save Changes
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={startEditing}
                              className="rounded-lg bg-[#0d5cff] hover:bg-[#0a4ad4] text-white text-sm font-semibold px-6 py-3 shadow-sm transition-colors inline-flex items-center gap-1.5"
                            >
                              <svg
                                viewBox="0 0 20 20"
                                className="h-4 w-4"
                                fill="none"
                                aria-hidden="true"
                              >
                                <path
                                  d="M13.5 3.5l3 3L7 16H4v-3L13.5 3.5Z"
                                  stroke="currentColor"
                                  strokeWidth="1.5"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                              </svg>
                              Edit
                            </button>
                            <button
                              onClick={() => {
                                setDeleteError(null);
                                setDeleteModalOpen(true);
                              }}
                              className="rounded-lg bg-[#ef3e55] hover:bg-red-600 text-white text-sm font-semibold px-6 py-3 shadow-sm transition-colors inline-flex items-center gap-1.5"
                            >
                              <svg
                                viewBox="0 0 20 20"
                                className="h-4 w-4"
                                fill="none"
                                aria-hidden="true"
                              >
                                <path
                                  d="M4 6h12M8 6V4.5A1.5 1.5 0 0 1 9.5 3h1A1.5 1.5 0 0 1 12 4.5V6m-6.5 0 .6 9.4A1.5 1.5 0 0 0 7.6 17h4.8a1.5 1.5 0 0 0 1.5-1.6L14.5 6"
                                  stroke="currentColor"
                                  strokeWidth="1.5"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                              </svg>
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    </section>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>,
        document.body,
      )}

      {saveCancelModal && (
        <SaveCancelModal
          type={saveCancelModal}
          onDone={() => setSaveCancelModal(null)}
          onConfirmCancel={confirmCancelEditing}
          onDismissConfirm={() => setSaveCancelModal(null)}
        />
      )}

      <DeleteModal
        open={deleteModalOpen}
        deleting={deleting}
        error={deleteError}
        onConfirm={handleDelete}
        onCancel={() => setDeleteModalOpen(false)}
      />
    </>
  );
}
