import { useEffect, useState } from "react";
import type { AccessPassRow } from "../../../../hooks/types";
import { StatusBadge } from "../StatusBadge";
import { AdminTableShell } from "../AdminTableShell";
import type { AdminColumn } from "../AdminTableShell";
import { ApplicantDetailModal } from "./ApplicantDetailModal";
import { TOKEN_KEY } from "../../../../providers/AuthProvider";
import { BASE } from "../../../../hooks/apiConfig";
import {
  useAccessPassBatchDownload,
  type BatchSize,
} from "../../../../hooks/useAccessPassBatchDownload";
import { BatchDownloadBar } from "./BatchDownloadBar";

const ENDPOINT = `${BASE}/api/admin/access-pass`;

const COLUMNS: AdminColumn<AccessPassRow>[] = [
  {
    header: "No.",
    align: "center",
    className: "w-16 text-[var(--smart-muted)]",
    render: (_row, i) => String(i + 1).padStart(2, "0"),
  },
  {
    header: "Application ID",
    className: "font-mono text-xs text-[var(--smart-muted)]",
    render: (row) => row.application_id,
  },
  {
    header: "Full Name",
    mobile: "title",
    className: "font-medium",
    render: (row) => row.full_name,
  },
  {
    header: "Applicant Type",
    className: "text-[var(--smart-muted)]",
    render: (row) => row.applicant_type,
  },
  {
    header: "Date Submitted",
    className: "text-[var(--smart-muted)]",
    render: (row) => row.date_submitted,
  },
  {
    header: "Status",
    mobile: "badge",
    render: (row) => <StatusBadge status={row.status} />,
  },
];

const searchText = (r: AccessPassRow) =>
  `${r.application_id} ${r.full_name} ${r.applicant_type} ${r.date_submitted} ${r.status}`;

const rowKey = (r: AccessPassRow) => r.application_id;

const ICON = (
  <svg
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <rect x="3" y="4" width="18" height="16" rx="2" />
    <circle cx="9" cy="10" r="2" />
    <path d="M15 8h3M15 12h3M6 16h12" />
  </svg>
);

export function AccessPassTable() {
  const [rows, setRows] = useState<AccessPassRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [selectedApplicantId, setSelectedApplicantId] = useState<number | null>(
    null,
  );

  // Batch ID download: selection is keyed by application_id (the row key).
  const [selectedKeys, setSelectedKeys] = useState<Set<string | number>>(
    new Set(),
  );
  const [batchSize, setBatchSize] = useState<BatchSize>("access-pass");
  const [selecting, setSelecting] = useState(false);
  const batch = useAccessPassBatchDownload();
  const approvedKeys = rows
    .filter((r) => r.status === "Approved")
    .map((r) => r.application_id);
  const selectedIds = rows
    .filter((r) => selectedKeys.has(r.application_id))
    .map((r) => r.applicant_id);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (reloadKey === 0) setLoading(true);
      setError(null);
      try {
        const token = sessionStorage.getItem(TOKEN_KEY);
        const res = await fetch(ENDPOINT, {
          headers: token ? { Authorization: `Bearer ${token}` } : {},
        });
        if (!res.ok) throw new Error("Request failed");
        const data: AccessPassRow[] = await res.json();
        if (!cancelled) setRows(data);
      } catch {
        if (!cancelled) setError("Could not load Access Pass applications.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  return (
    <>
      <AdminTableShell
        tableNumber="01"
        title="Access Pass Application"
        accent="red"
        icon={ICON}
        columns={COLUMNS}
        rows={rows}
        rowKey={rowKey}
        searchText={searchText}
        onRowClick={(row) => setSelectedApplicantId(row.applicant_id)}
        loading={loading}
        error={error}
        selectable={selecting}
        isSelectable={(r) => r.status === "Approved"}
        selectedKeys={selectedKeys}
        onSelectionChange={(keys) => {
          setSelectedKeys(keys);
          batch.reset();
        }}
        toolbar={
          <BatchDownloadBar
            selectedCount={selectedIds.length}
            eligibleCount={approvedKeys.length}
            onSelectAll={() => {
              setSelectedKeys(new Set(approvedKeys));
              batch.reset();
            }}
            size={batchSize}
            onSizeChange={setBatchSize}
            downloading={batch.downloading}
            error={batch.error}
            notice={batch.notice}
            onDownload={() => batch.download(selectedIds, batchSize)}
            selecting={selecting}
            onStart={() => setSelecting(true)}
            onCancel={() => {
              setSelecting(false);
              setSelectedKeys(new Set());
              batch.reset();
            }}
          />
        }
      />
      <ApplicantDetailModal
        applicantId={selectedApplicantId}
        onClose={() => setSelectedApplicantId(null)}
        onChanged={() => setReloadKey((k) => k + 1)}
        onDeleted={() => setReloadKey((k) => k + 1)}
      />
    </>
  );
}
